# Find the area and circumference of circle?

# take radius as input from user
radius = int(input("Enter radius of circle: "))
pi = 3.14

# perform operation to find area and circumference
area = pi * radius * radius
circumference = 2 * pi * radius
print("Area of circle is:", area,"\n")
print("Circumference of circle is:", circumference,"\n") 