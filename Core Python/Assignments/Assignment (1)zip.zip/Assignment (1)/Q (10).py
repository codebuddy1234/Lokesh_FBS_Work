# Write a program to calculate area of an equilateral triangle ?

# take side of triangle as input from user
side = int(input("Enter side of equilateral triangle: "))

# perform operation to find area
area = (3**0.5 / 4) * side ** 2
print("Area of equilateral triangle is:", area,"\n")

#display area
print(f'Area of equilateral triangle is :{area}') # f string is use for formatted string at one place