# Write a program to enter base and height of a triangle and find its area.

# Collect input from user
Base = int(input("Enter base of triangle:"))
Height = int(input("Enter Height of triangle:"))

# perform operation to find area
Area = 1/2 * Base * Height
print("Area of triangle is:", Area,"\n") 