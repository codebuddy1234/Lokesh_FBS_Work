# Find the volume of sphere ?

# take radius as input from user
radius = int(input("Enter radius of sphere: "))
pi = 3.14

# perform operation to find volume
volume = (4/3) * pi * radius ** 3
print(f'"Volume of sphere is:", {volume}')